CREATE DATABASE IF NOT EXISTS myDB;
USE myDB;

DROP TABLE IF EXISTS test;


CREATE TABLE IF NOT EXISTS test (
  id serial NOT NULL PRIMARY KEY,
  name varchar(100),
  email varchar(200),
  department varchar(200),
  modified timestamp default CURRENT_TIMESTAMP NOT NULL,
  INDEX `modified_index` (`modified`)
);
USE myDB;
INSERT INTO test (name, email, department) VALUES ('clarissa', 'clarissa@abc.com', 'eng.');
INSERT INTO test (name, email, department) VALUES ('clarissa1', '1@abc.com', 'Fin');
INSERT INTO test (name, email, department) VALUES ('clarissa2', '2@abc.com', 'IT');
INSERT INTO test (name, email, department) VALUES ('clarissa3', '3@abc.com', 'Des');
INSERT INTO test (name, email, department) VALUES ('clarissa4', '4@abc.com', 'Mark');
INSERT INTO test (name, email, department) VALUES ('clarissa5', '5@abc.com', 'CEO');
INSERT INTO test (name, email, department) VALUES ('clarissa6', '6@abc.com', 'IT');
INSERT INTO test (name, email, department) VALUES ('clarissa7', '7@abc.com', 'IT');
INSERT INTO test (name, email, department) VALUES ('clarissa8', '8@abc.com', 'IT');
INSERT INTO test (name, email, department) VALUES ('clarissa9', '9@abc.com', 'IT');

